import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { CustomerProfile } from '../models/customerProfile';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
}

@Injectable({
  providedIn: 'root'
})
export class CustomerProfileService {
  id:string
  customerUrl:string = 'http://localhost:8085/rest/customers/'


  constructor(private http:HttpClient) {}

  // Get accounts
  getcustomerDetailsById(id:string):Observable<CustomerProfile> {
    return this.http.get<CustomerProfile>(`${this.customerUrl}/${id}`);
  }
  getcustomerDetails():Observable<CustomerProfile[]> {
    return this.http.get<CustomerProfile[]>(this.customerUrl);
  }
  // Delete account
  deletecustomerDetails(customer:CustomerProfile):Observable<CustomerProfile> {
    const url = `${this.customerUrl}/${customer.cid}`;
    return this.http.delete<CustomerProfile>(url, httpOptions);
  }

  // Add account
  addcustomerDetails(customer:CustomerProfile):Observable<CustomerProfile> {
    return this.http.post<CustomerProfile>(this.customerUrl, customer, httpOptions);
  }
  updatecustomerDetails(customer:CustomerProfile):Observable<CustomerProfile>{
    return this.http.put<CustomerProfile>(this.customerUrl,customer,httpOptions)
  }
  

}


