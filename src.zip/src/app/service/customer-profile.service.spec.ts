import { TestBed } from '@angular/core/testing';

import { CustomerProfileService } from './customer-profile.service';

describe('CustomerProfileService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CustomerProfileService = TestBed.get(CustomerProfileService);
    expect(service).toBeTruthy();
  });
});
