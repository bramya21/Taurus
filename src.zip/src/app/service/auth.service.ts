import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
public isAuth:boolean = false
 public typeofUser:string
 public uid:number
 constructor() { }
 changeAuthToAccess(type){
   this.isAuth = true
   this.typeofUser=type
 } 
 isloggedOut(){
   this.isAuth = false
   this.typeofUser=null
 }
}
