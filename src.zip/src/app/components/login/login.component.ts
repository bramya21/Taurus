// import { Component, OnInit } from '@angular/core';
// import { AuthService } from 'src/app/service/auth.service';

import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import {Router} from '@angular/router'

import { User } from '../../models/User';
import {AccountsService} from '../../service/accounts.service'
import { AuthService } from 'src/app/service/auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  public user:User=new User('','',0);
  regiForm: FormGroup;  

  constructor(public route:Router,
              private service : AccountsService,
              private auth:AuthService,
              private fb: FormBuilder) {
    auth.isValidLogin = false
    auth.typeofUser = auth.uid = null
    this.regiForm = fb.group({  
      'UserName' : [null, Validators.required],
      'Password' : [null, Validators.required]
   });
   
  }
  onFormSubmit(form:NgForm)  
  {  
    console.log(this.user)
      if(this.user.userId=='dbsemployee@dbs.com'){
        this.auth.changeAuthToAccess('employee'); 
        this.route.navigate(['/account'])
        return null
      }
      let resp = this.service.
      isValidLogin(this.user).
      toPromise().then(data=>{
        console.log(data);
        this.auth.uid=data.cid;
        this.auth.changeAuthToAccess('customer');
        this.route.navigate(['/profile'])
        });

      //  if(resp){
       
      // }
  }

}