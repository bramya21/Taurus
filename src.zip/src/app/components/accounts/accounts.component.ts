import { Component, OnInit } from '@angular/core';
import { AccountsService } from '../../service/accounts.service';
// import { ActivatedRoute } from '@angular/router';
import {MatTableDataSource} from '@angular/material/table';

import { Account } from '../../models/Accounts'
@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.css']
})
export class AccountsComponent implements OnInit {
  accounts:Account[];
  viewAccounts:boolean =  false
 

  constructor(private accountService:AccountsService) { }

  ngOnInit() {
    this.accountService.getaccounts().subscribe(accounts => {
      this.accounts = accounts;
     
    });
   
  }
  

  deleteaccount(account:Account) {
    // Remove From UI
    console.log(account)
    this.accounts = this.accounts.filter(t => t.cid !== account.cid);
    // Remove from server
    this.accountService.deleteaccount(account).subscribe();
  }

  addaccount(account:Account) {
    this.accountService.addaccount(account).subscribe(account => {
      this.accounts.push(account);
    });
  }
}
