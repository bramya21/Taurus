import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators ,FormsModule,NgForm } from '@angular/forms'; 
import {CustomerProfileService} from '../../service/customer-profile.service';
import {CustomerProfile} from '../../models/CustomerProfile';
import {Router} from '@angular/router'
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit{  
  title = 'material-demo';

  regiForm: FormGroup;  
  FirstName:string='';  
  LastName:string='';  
  Address:string='';  
  DOB:Date=null;  
  Gender:string='';  
  Email:string='';  
  IsAccepted:number=0;  
 register:CustomerProfile = new CustomerProfile();

  constructor(private fb: FormBuilder,private cp:CustomerProfileService,private route:Router) {   
    // this.cp.getcustomerDetailsById('100').subscribe(data=> {this.customer = data; console.log(this.customer)})
    
   console.log(this.register)
    // To initialize FormGroup  
    this.regiForm = fb.group({  
      'FirstName' : [null, Validators.required],  
      'LastName' : [null, Validators.required],
      'Password':[null,Validators.required],
      'Address' : [null, Validators.compose([Validators.required, Validators.minLength(30), Validators.maxLength(500)])],  
      'DOB' : [null, Validators.required],  
      'Gender':[null, Validators.required],  
      'Account':[null, Validators.required],  
      'Email':[null, Validators.compose([Validators.required,Validators.email])], 
      'PhoneNumber':[null,Validators.compose([Validators.required,Validators.minLength(10),Validators.maxLength(10)]) ],
      'AdharNo':[null,Validators.compose([Validators.required,Validators.minLength(12),Validators.maxLength(12)]) ]

      // 'IsAccepted':[null]  
    });  
  
  }    
  // Executed When Form Is Submitted  
  onFormSubmit(form:NgForm)  
  {  
    console.log(form); 
    console.log(this.register.password) 
    console.log(this.register)
    this.cp.addcustomerDetails(this.register).subscribe(data => console.log(data))
    this.route.navigate(['/login'])
  }
  ngOnInit(){
   }  
   
}  