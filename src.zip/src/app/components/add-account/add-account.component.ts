import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Account } from 'src/app/models/Accounts';
import { FormBuilder, FormGroup, Validators ,FormsModule,NgForm } from '@angular/forms';  

@Component({
  selector: 'app-add-account',
  templateUrl: './add-account.component.html',
  styleUrls: ['./add-account.component.css']
})
export class AddAccountComponent implements OnInit {
  @Output() addaccount: EventEmitter<any> = new EventEmitter();
 //form fields
  regiForm: FormGroup;  
  BranchName:string='';  
  Balance:string='';  
 
  DateSelector:Date=null;  
  AccountType:string='';  
  Email:string='';  
  // data base account fields
  cid:number = 10;
  branch:string;
  acctype:string;
  accno:string = '2565';
  balance:number;
  constructor(private fb: FormBuilder) { 
    this.regiForm = fb.group({  
      'BranchName' : [null, Validators.required],  
      'Balance' : [null, Validators.compose([Validators.required , Validators.pattern('^[0-9]*')])],    
      'AccountType':[null, Validators.required],  
      'Email':[null, Validators.compose([Validators.required,Validators.email])]
    }); 
  }

  ngOnInit() {
  }

  onSubmit() {
    const account = {
      "cid":this.cid,
      "branch":this.branch,
      "balance":this.balance,
      "acctype":this.acctype,
      "accno":this.accno

    }
    this.addaccount.emit(account);
  }
  onFormSubmit(form:NgForm)  
  {  
    console.log(form);
    const account = {
      "cid":this.cid,
      "branch":form['BranchName'],
      "balance":form['Balance'],
      "acctype":form['AccountType'],
      "accno":this.accno

    }  
    this.addaccount.emit(account);
  }  
}
