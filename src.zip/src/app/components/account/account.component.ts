import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';

import { Account } from '../../models/Accounts'
import { AuthService } from 'src/app/service/auth.service';
@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  @Input() account: Account;
  @Output() deleteaccount: EventEmitter<Account> = new EventEmitter();
  displayedColumns: string[] = ['Account Type', 'Balance', 'Account Number','Branch'];
  dataSource = new MatTableDataSource([this.account]);

  constructor(public auth:AuthService) { }

  ngOnInit() {
  }
  onDelete(account) {
    this.deleteaccount.emit(account);
  }
}
