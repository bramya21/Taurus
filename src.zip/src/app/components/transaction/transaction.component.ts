import { Component, OnInit } from '@angular/core';
import { Transaction } from '../../models/Transactions'
import { AccountsService } from '../../service/accounts.service'
import { formatDate } from '@angular/common';
import { FormBuilder, FormGroup, Validators ,FormsModule,NgForm } from '@angular/forms'; 
@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

regiForm: FormGroup;  
fromaccount:number = 1000
toAccount:number
amount:number
transactionid:number
date:Date  
transaction:Transaction
transactions:Transaction[]=[]
requestedTransactions:boolean= false
constructor(private account:AccountsService,private fb: FormBuilder) { 
  this.regiForm = fb.group({  
    'Amount' : [null, Validators.required],  
    'TransactionId' : [null, Validators.compose([Validators.required , Validators.pattern('^[0-9]*')])],    
    'ToAccount':[null, Validators.required]
  }); 
}

  ngOnInit() {
    this.transaction={
      "tid": this.transactionid,
      "fromaccount":this.fromaccount,
      "toaccount":this.toAccount,
      "ammouttransffered":this.amount,
      "transactiondate":null
    }
    this.account.getTransactions(this.transaction).subscribe(

      transactions => {
        console.log(transactions);
        this.transactions = transactions
      }
    )
  }
 
  onTransaction(){
    this.date = new Date()
    const dateFormat = formatDate(this.date,'yyyy-MM-dd','en')
    this.transaction={
      "tid": this.transactionid,
      "fromaccount":2567,
      "toaccount":this.toAccount,
      "ammouttransffered":this.amount,
      "transactiondate":dateFormat
    }
    console.log(this.transaction)
    this.account.addTransaction(this.transaction).subscribe(
      transaction => console.log(transaction)
    );
  }
  onGetTransaction(){
    this.requestedTransactions = true
    
  }
  onFormSubmit(regiForm:NgForm){
    this.date = new Date()
    const dateFormat = formatDate(this.date,'yyyy-MM-dd','en')
    this.transaction={
      "tid": regiForm['TransactionId'],
      "fromaccount":1001,
      "toaccount":regiForm['ToAccount'],
      "ammouttransffered":regiForm['Amount'],
      "transactiondate":dateFormat
    }
    console.log(this.transaction)
    this.account.addTransaction(this.transaction).subscribe(
      transaction => console.log(transaction)
    );
  }
}
