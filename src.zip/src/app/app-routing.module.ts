import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProfileComponent } from './profile/profile.component';
import { AccountsComponent } from './components/accounts/accounts.component';
import {TransactionComponent} from './components/transaction/transaction.component'
import{GettransactionsComponent} from './components/gettransactions/gettransactions.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
const routes: Routes = [
  {path:'profile',component:ProfileComponent},
  {path:'account',component:AccountsComponent},
  {path:'transaction',component:TransactionComponent},
  {path:'gettransactions',component:GettransactionsComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'login',component:LoginComponent},
  {path:'home',component:HomeComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
 }
