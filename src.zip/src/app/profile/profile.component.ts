import { Component, OnInit, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators ,FormsModule,NgForm } from '@angular/forms'; 
import {CustomerProfileService} from '../service/customer-profile.service';
import {CustomerProfile} from '../models/CustomerProfile';
import { AuthService } from '../service/auth.service';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

  
export class ProfileComponent implements OnInit,OnChanges{  
  title = 'material-demo';

  customer:CustomerProfile

  constructor(private cp:CustomerProfileService,private auth:AuthService) {   
    
    // To initialize FormGroup  
    // this.regiForm = fb.group({  
    //   'FirstName' : [null, Validators.required],  
    //   'LastName' : [null, Validators.required],  
    //   'Address' : [null, Validators.compose([Validators.required, Validators.minLength(30), Validators.maxLength(500)])],  
    //   'DOB' : [null, Validators.required],  
    //   'Gender':[null, Validators.required],  
    //   'Account':[null, Validators.required],  
    //   'Email':[null, Validators.compose([Validators.required,Validators.email])], 
    //   'PhoneNumber':[null,Validators.compose([Validators.required,Validators.minLength(10),Validators.maxLength(10)]) ],
    //   'AdharNo':[null,Validators.compose([Validators.required,Validators.minLength(12),Validators.maxLength(12)]) ]

    //   // 'IsAccepted':[null]  
    // });  
    this.cp.getcustomerDetailsById('662').subscribe(data=> {this.customer = data; console.log(this.customer)})

  
  }  
  
  // On Change event of Toggle Button  
  onChange(event:any)  
  {  
 
  }  
  
  // Executed When Form Is Submitted  
  onFormSubmit(form:NgForm)  
  {  
    console.log(form);  
  }
  ngOnInit(){
    // this.cp.getcustomerDetailsById('1').subscribe(data => {this.customer=data; console.log(this.customer)});
  }
  ngOnChanges(){
      // 'IsAccepted':[null]  
  }
    
}  

