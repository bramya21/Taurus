import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators ,FormsModule,NgForm } from '@angular/forms'; 
import {CustomerProfileService} from '../../service/customer-profile.service';
import {CustomerProfile} from '../../models/CustomerProfile';
import { AuthService } from 'src/app/service/auth.service';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit{  
  title = 'material-demo';

  regiForm: FormGroup;  
  FirstName:string='';  
  LastName:string='';  
  Address:string='';  
  DOB:Date=null;  
  Gender:string='';  
  Email:string='';  
  IsAccepted:number=0;  
 customer:CustomerProfile = new CustomerProfile();

  constructor(private fb: FormBuilder,private cp:CustomerProfileService,private auth:AuthService) {   
    console.log(auth.uid)
    this.cp.getcustomerDetailsById(auth.uid).toPromise().then(data=> {this.customer = data; console.log(this.customer)})
    
   console.log(this.customer)
    // To initialize FormGroup  
    this.regiForm = fb.group({  
      'FirstName' : [null, Validators.required],  
      'LastName' : [null, Validators.required],  
      'Address' : [null, Validators.compose([Validators.required, Validators.minLength(30), Validators.maxLength(500)])],  
      'DOB' : [null, Validators.required],  
      'Gender':[null, Validators.required],  
      'Account':[null, Validators.required],  
      'Email':[null, Validators.compose([Validators.required,Validators.email])], 
      'PhoneNumber':[null,Validators.compose([Validators.required,Validators.minLength(10),Validators.maxLength(10)]) ],
      'AdharNo':[null,Validators.compose([Validators.required,Validators.minLength(12),Validators.maxLength(12)]) ]

      // 'IsAccepted':[null]  
    });  
  
  }    
  // Executed When Form Is Submitted  
  onFormSubmit(form:NgForm)  
  {  
    console.log(form); 
    console.log(this.customer,this.customer.dob) 
    
    this.cp.updatecustomerDetails(this.customer).subscribe(data => console.log(data))
  }
  ngOnInit(){
   }  
}  