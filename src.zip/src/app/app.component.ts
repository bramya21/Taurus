import { Component,OnInit } from '@angular/core';
import {CustomerProfileService} from './service/customer-profile.service'
import {CustomerProfile} from './models/CustomerProfile';
import { MatDialog,MatDialogConfig } from '@angular/material';
import {BnNgIdleService} from 'bn-ng-idle'
import { TransactionComponent } from './components/transaction/transaction.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

  
export class AppComponent implements OnInit
{
  title = 'material-demo';
  customers:CustomerProfile[]
  constructor(private cp:CustomerProfileService,public dialog:MatDialog,public bnIdle:BnNgIdleService){
    this.bnIdle.startWatching(10).subscribe((res) => {
      if(res) {
          console.log("session expired");
          // this.openDialog();
      }
    })    
  }
  openDialog(){
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    this.dialog.open(TransactionComponent, dialogConfig);
  }
  onUpdate(){
    console.log(this.customers)
  }
  ngOnInit(){
    this.cp.getcustomerDetails().subscribe(data => {this.customers=data})

  }
}
