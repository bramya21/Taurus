import { BrowserModule } from '@angular/platform-browser';  
import { NgModule } from '@angular/core';  
import{HttpClientModule} from '@angular/common/http';
import {AppRoutingModule} from './app-routing.module'
import { FormsModule,ReactiveFormsModule } from '@angular/forms';  
import { BnNgIdleService} from 'bn-ng-idle'
import {  
  MatListModule,
  MatDividerModule,
  MatButtonModule,  
  MatMenuModule,  
  MatToolbarModule,  
  MatIconModule,  
  MatCardModule,  
  MatFormFieldModule,  
  MatInputModule,  
  MatDatepickerModule,  
  MatDatepicker,  
  MatNativeDateModule,  
  MatRadioModule,  
  MatSelectModule,  
  MatOptionModule,  
  MatSidenavModule,
  MatTooltipModule,   
  MatSlideToggleModule,ErrorStateMatcher,ShowOnDirtyErrorStateMatcher  
} from '@angular/material';  
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';  
import { AppComponent } from './app.component';
import { ProfileComponent } from './profile/profile.component';
import { UpdateComponent } from './profile/update/update.component';
import { HeaderComponent } from './header/header.component';
import { MatGridListModule } from '@angular/material/grid-list';
import { LayoutModule } from '@angular/cdk/layout';  
import { FlexLayoutModule } from '@angular/flex-layout';
import { AccountComponent } from './components/account/account.component';
import { AccountsComponent } from './components/accounts/accounts.component';
import { AddAccountComponent } from './components/add-account/add-account.component';
import { TransactionComponent } from './components/transaction/transaction.component';
import {MatTableModule} from '@angular/material/table';
import {MatDialogModule} from '@angular/material/dialog';
import { GettransactionsComponent } from './components/gettransactions/gettransactions.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { DialogComponent } from './components/dialog/dialog.component';
import { LoginComponent } from './components/login/login.component'
// import { ParticlesModule } from '@angular-particle';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HomeComponent } from './components/home/home.component';
import { FooterComponent } from './footer/footer.component';

  
@NgModule({  
  declarations: [  
    AppComponent, ProfileComponent, UpdateComponent, HeaderComponent, AccountComponent, AccountsComponent, AddAccountComponent, TransactionComponent, GettransactionsComponent, RegistrationComponent, DialogComponent, LoginComponent, HomeComponent, FooterComponent  
  ],  
  imports: [ 
    // ParticlesModule, 
    MatListModule,
    MatDividerModule,
    NgbModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    MatDialogModule,
    MatTableModule,
    BrowserModule,  
    FormsModule,  
    ReactiveFormsModule,  
    MatButtonModule,  
    MatMenuModule,  
    MatToolbarModule,  
    MatIconModule,
    FlexLayoutModule,  
    MatCardModule,  
    BrowserAnimationsModule,  
    MatFormFieldModule,  
    MatInputModule,  
    MatDatepickerModule,  
    MatNativeDateModule,  
    MatRadioModule,  
    MatSelectModule,  
    MatOptionModule,  
    MatSlideToggleModule ,
    HttpClientModule ,
    AppRoutingModule,
    MatGridListModule,
    LayoutModule,
    MatSidenavModule
  ],  
  exports: [  
    MatButtonModule,  
    MatMenuModule,  
    MatToolbarModule,  
    MatIconModule,  
    MatCardModule,  
    BrowserAnimationsModule,  
    MatFormFieldModule,  
    MatInputModule,  
    MatDatepickerModule,  
    MatNativeDateModule,  
    MatRadioModule,  
    MatSelectModule,  
    MatOptionModule,  
    MatSlideToggleModule,
    MatDialogModule  
  ],  
  providers: [  
    {provide: ErrorStateMatcher, useClass: ShowOnDirtyErrorStateMatcher},
    BnNgIdleService  
  ],  
  bootstrap: [AppComponent],
  entryComponents:[TransactionComponent]
  
})  
export class AppModule { }  
