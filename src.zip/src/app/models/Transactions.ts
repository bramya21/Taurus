export class Transaction{
    tid:number
    fromaccount:number
    toaccount:number
    transactiondate:string
    ammouttransffered:number
}