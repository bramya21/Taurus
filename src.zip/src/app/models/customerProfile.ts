export class CustomerProfile{
    cid :number
    firstname:string
    lastname:string
    password:String
    phonenumber:string
    adharnumber:string
    address:string
    dob:Date
    gender:string
    accounttype:string
    email:string  
}