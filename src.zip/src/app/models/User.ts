export class User {
    constructor(public userId:string,public password:string,public cid:number )
    {

    }
}