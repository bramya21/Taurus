export class Account {
    cid:number;
    branch:string;
    acctype:string;
    accno:string;
    balance:number;
  }